package com.project.theatre_service.dto.seat;

import com.project.theatre_service.entity.seat.SeatStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatStatusUpdateRequest {
    private SeatStatus status;
}
